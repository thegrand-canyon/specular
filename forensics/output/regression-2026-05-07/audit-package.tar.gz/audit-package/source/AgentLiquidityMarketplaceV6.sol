// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "./AgentRegistryV2.sol";
import "./ReputationManagerV3.sol";

/**
 * @title AgentLiquidityMarketplaceV6
 * @notice P2P lending marketplace — v6 with §B1, §S1, §S5 fixes + migration helpers.
 * @dev Drop-in successor to v4. Storage layout intentionally NOT compatible — fresh deploy + migrate.
 *
 * Fixes vs v4:
 *   §B1 — `isInPoolLenders` flag prevents duplicate poolLenders entries on supply→withdraw→supply.
 *         Added `compactPoolLenders(agentId)` admin to dedup any state seeded from v4.
 *   §S1 — `claimInterest` decrements `pool.availableLiquidity` to match the USDC leaving the contract.
 *   §S5 — `activeLoanCount` mapping replaces `_countActiveLoans` array walk (O(N) → O(1)).
 *
 * Admin migration helpers (owner-only, locked once setMigrationFinalized() called):
 *   - `seedPool(agentId, agentAddress, totalLiquidity, availableLiquidity, totalEarned)`
 *   - `seedPosition(agentId, lender, amount, earnedInterest, depositTimestamp)`
 *   - `compactPoolLenders(agentId)` — dedup any state seeded from v4
 *   - `setMigrationFinalized()` — irreversibly disables seed* and unlocks normal operation
 *
 * NOT independently audited. Do not deploy to Base mainnet without external review.
 */
contract AgentLiquidityMarketplaceV6 is Ownable, ReentrancyGuard, Pausable {
    using SafeERC20 for IERC20;

    // State variables (set in constructor, immutable for gas savings — slither finding)
    AgentRegistryV2 public immutable agentRegistry;
    ReputationManagerV3 public immutable reputationManager;
    IERC20 public immutable usdcToken;

    // Agent liquidity pools
    struct AgentPool {
        uint256 agentId;
        address agentAddress;
        uint256 totalLiquidity;      // Total USDC supplied to this agent
        uint256 availableLiquidity;  // USDC available for borrowing
        uint256 totalLoaned;         // Currently loaned out
        uint256 totalEarned;         // Total interest earned
        bool isActive;               // Agent can accept liquidity
    }

    // Lender position tracking
    struct LenderPosition {
        uint256 amount;              // USDC supplied to agent
        uint256 earnedInterest;      // Interest earned so far
        uint256 depositTimestamp;    // When they deposited
    }

    // Loan tracking
    struct Loan {
        uint256 loanId;
        address borrower;
        uint256 agentId;
        uint256 amount;
        uint256 collateralAmount;
        uint256 interestRate;        // Basis points (e.g., 500 = 5%)
        uint256 startTime;
        uint256 endTime;
        uint256 duration;            // In days
        LoanState state;
    }

    enum LoanState {
        REQUESTED,
        ACTIVE,
        REPAID,
        DEFAULTED
    }

    // Mappings
    mapping(uint256 => AgentPool) public agentPools;                          // agentId => pool
    mapping(uint256 => mapping(address => LenderPosition)) public positions;  // agentId => lender => position
    mapping(uint256 => address[]) public poolLenders;                         // agentId => lender addresses
    mapping(uint256 => Loan) public loans;                                    // loanId => loan
    mapping(address => uint256[]) public agentLoans;                          // agent => loanIds

    uint256 public nextLoanId = 1;
    uint256 public platformFeeRate = 100; // 1% platform fee (in basis points)
    uint256 public accumulatedFees;

    // Discovery: ordered list of all agent IDs that have created pools
    uint256[] public agentPoolIds;

    // §S5 fix: O(1) active-loan counter — replaces _countActiveLoans array walk
    mapping(address => uint256) public activeLoanCount;

    // §B1 fix: presence flag — gates poolLenders.push(), prevents duplicate entries
    mapping(uint256 => mapping(address => bool)) public isInPoolLenders;

    // Migration phase — owner can seed* state until finalized; irreversible after finalization
    bool public migrationFinalized;

    // Constants
    uint256 public constant MAX_INTEREST_RATE = 2000; // 20% max
    uint256 public constant MIN_LOAN_DURATION = 7 days;
    uint256 public constant MAX_LOAN_DURATION = 365 days;
    // [H-04 mitigation] Cap lenders per pool to bound _distributeInterest gas cost
    uint256 public constant MAX_LENDERS_PER_POOL = 50;
    // [SECURITY-01] Limit concurrent active loans per agent to prevent credit limit bypass
    uint256 public constant MAX_ACTIVE_LOANS_PER_AGENT = 10;

    // Events
    event PoolCreated(uint256 indexed agentId, address indexed agentAddress);
    event LiquiditySupplied(uint256 indexed agentId, address indexed lender, uint256 amount);
    event LiquidityWithdrawn(uint256 indexed agentId, address indexed lender, uint256 amount);
    event LoanRequested(uint256 indexed loanId, uint256 indexed agentId, address indexed borrower, uint256 amount);
    event LoanDisbursed(uint256 indexed loanId, uint256 amount);
    event LoanRepaid(uint256 indexed loanId, uint256 principal, uint256 interest);
    event LoanDefaulted(uint256 indexed loanId);
    event InterestDistributed(uint256 indexed agentId, uint256 totalInterest);
    event InterestClaimed(uint256 indexed agentId, address indexed lender, uint256 amount);
    event PoolLendersCompacted(uint256 indexed agentId, uint256 removed);
    event MigrationFinalized();
    event PoolSeeded(uint256 indexed agentId, address indexed agentAddress);
    event PositionSeeded(uint256 indexed agentId, address indexed lender, uint256 amount, uint256 earnedInterest);
    event FeesWithdrawn(address indexed to, uint256 amount);

    constructor(
        address _agentRegistry,
        address _reputationManager,
        address _usdcToken
    ) Ownable(msg.sender) {
        agentRegistry = AgentRegistryV2(_agentRegistry);
        reputationManager = ReputationManagerV3(_reputationManager);
        usdcToken = IERC20(_usdcToken);
    }

    /**
     * @notice Create a liquidity pool for an agent
     */
    function createAgentPool() external whenNotPaused {
        uint256 agentId = agentRegistry.addressToAgentId(msg.sender);
        require(agentId != 0, "Not a registered agent");
        require(!agentPools[agentId].isActive, "Pool already exists");

        agentPools[agentId] = AgentPool({
            agentId: agentId,
            agentAddress: msg.sender,
            totalLiquidity: 0,
            availableLiquidity: 0,
            totalLoaned: 0,
            totalEarned: 0,
            isActive: true
        });

        agentPoolIds.push(agentId);

        emit PoolCreated(agentId, msg.sender);
    }

    /**
     * @notice Returns the total number of agent pools created
     */
    function totalPools() external view returns (uint256) {
        return agentPoolIds.length;
    }

    /**
     * @notice Supply liquidity to a specific agent's pool
     */
    function supplyLiquidity(uint256 agentId, uint256 amount) external nonReentrant whenNotPaused {
        require(amount > 0, "Amount must be > 0");
        require(agentPools[agentId].isActive, "Pool not active");

        AgentPool storage pool = agentPools[agentId];
        LenderPosition storage position = positions[agentId][msg.sender];

        // Transfer USDC from lender
        usdcToken.safeTransferFrom(msg.sender, address(this), amount);

        // Update pool
        pool.totalLiquidity += amount;
        pool.availableLiquidity += amount;

        // §B1 FIX: gate push on isInPoolLenders flag instead of `position.amount == 0`.
        // This ensures that supply→withdraw→supply does NOT create a duplicate entry.
        if (!isInPoolLenders[agentId][msg.sender]) {
            require(
                poolLenders[agentId].length < MAX_LENDERS_PER_POOL,
                "Pool lender capacity reached"
            );
            poolLenders[agentId].push(msg.sender);
            isInPoolLenders[agentId][msg.sender] = true;
            position.depositTimestamp = block.timestamp;
        }
        position.amount += amount;

        emit LiquiditySupplied(agentId, msg.sender, amount);
    }

    /**
     * @notice Withdraw liquidity from an agent's pool
     */
    function withdrawLiquidity(uint256 agentId, uint256 amount) external nonReentrant whenNotPaused {
        LenderPosition storage position = positions[agentId][msg.sender];
        AgentPool storage pool = agentPools[agentId];

        require(position.amount >= amount, "Insufficient balance");
        require(pool.availableLiquidity >= amount, "Insufficient pool liquidity");

        // Update position
        position.amount -= amount;

        // Update pool
        pool.totalLiquidity -= amount;
        pool.availableLiquidity -= amount;

        // Transfer USDC back to lender
        usdcToken.safeTransfer(msg.sender, amount);

        emit LiquidityWithdrawn(agentId, msg.sender, amount);
    }

    /**
     * @notice Agent requests a loan from their dedicated pool
     */
    function requestLoan(uint256 amount, uint256 durationDays) external nonReentrant whenNotPaused returns (uint256) {
        uint256 agentId = agentRegistry.addressToAgentId(msg.sender);
        require(agentId != 0, "Not a registered agent");
        require(agentPools[agentId].isActive, "No pool for agent");

        AgentPool storage pool = agentPools[agentId];
        require(amount <= pool.availableLiquidity, "Insufficient pool liquidity");

        // Validate loan parameters
        uint256 duration = durationDays * 1 days;
        require(duration >= MIN_LOAN_DURATION && duration <= MAX_LOAN_DURATION, "Invalid duration");

        // Get credit limit based on reputation
        uint256 creditLimit = reputationManager.calculateCreditLimit(msg.sender);
        require(amount <= creditLimit, "Exceeds credit limit");

        // [SECURITY-01] Enforce concurrent loan limit to prevent credit limit bypass
        uint256 activeLoans = _countActiveLoans(msg.sender);
        require(activeLoans < MAX_ACTIVE_LOANS_PER_AGENT, "Too many active loans");

        // Calculate collateral requirement
        uint256 collateralPercent = reputationManager.calculateCollateralRequirement(msg.sender);
        uint256 requiredCollateral = (amount * collateralPercent) / 100;

        // Get interest rate
        uint256 interestRate = reputationManager.calculateInterestRate(msg.sender);

        // Create loan
        uint256 loanId = nextLoanId++;
        loans[loanId] = Loan({
            loanId: loanId,
            borrower: msg.sender,
            agentId: agentId,
            amount: amount,
            collateralAmount: requiredCollateral,
            interestRate: interestRate,
            startTime: 0, // Set when disbursed
            endTime: 0,
            duration: duration,
            state: LoanState.REQUESTED
        });

        agentLoans[msg.sender].push(loanId);

        emit LoanRequested(loanId, agentId, msg.sender, amount);

        // Auto-disburse if no collateral required
        if (requiredCollateral == 0) {
            _disburseLoan(loanId);
        } else {
            // Require collateral to be deposited
            usdcToken.safeTransferFrom(msg.sender, address(this), requiredCollateral);
            _disburseLoan(loanId);
        }

        return loanId;
    }

    /**
     * @notice Internal function to disburse loan
     */
    function _disburseLoan(uint256 loanId) internal {
        Loan storage loan = loans[loanId];
        AgentPool storage pool = agentPools[loan.agentId];

        require(loan.state == LoanState.REQUESTED, "Invalid loan state");

        // Update pool
        pool.availableLiquidity -= loan.amount;
        pool.totalLoaned += loan.amount;

        // Update loan
        loan.state = LoanState.ACTIVE;
        loan.startTime = block.timestamp;
        loan.endTime = block.timestamp + loan.duration;

        // §S5 FIX: increment counter on transition to ACTIVE
        activeLoanCount[loan.borrower]++;

        // Transfer funds to borrower
        usdcToken.safeTransfer(loan.borrower, loan.amount);

        // Record with reputation manager
        reputationManager.recordBorrow(loan.borrower, loan.amount);

        emit LoanDisbursed(loanId, loan.amount);
    }

    /**
     * @notice Repay a loan
     */
    function repayLoan(uint256 loanId) external nonReentrant whenNotPaused {
        Loan storage loan = loans[loanId];
        require(msg.sender == loan.borrower, "Not the borrower");
        require(loan.state == LoanState.ACTIVE, "Loan not active");

        // Calculate interest
        uint256 interest = calculateInterest(
            loan.amount,
            loan.interestRate,
            loan.duration
        );

        uint256 totalRepayment = loan.amount + interest;

        // Calculate platform fee
        uint256 platformFee = (interest * platformFeeRate) / 10000;
        uint256 lenderInterest = interest - platformFee;

        // [C-01 FIX] Collect repayment FIRST before any state changes (strict CEI)
        usdcToken.safeTransferFrom(msg.sender, address(this), totalRepayment);

        // EFFECTS: update state only after funds confirmed received
        loan.state = LoanState.REPAID;

        // §S5 FIX: decrement counter on transition out of ACTIVE
        activeLoanCount[loan.borrower]--;

        // Update pool
        AgentPool storage pool = agentPools[loan.agentId];
        pool.availableLiquidity += loan.amount + lenderInterest;
        pool.totalLoaned -= loan.amount;
        pool.totalEarned += lenderInterest;

        // Distribute interest to lenders proportionally
        _distributeInterest(loan.agentId, lenderInterest);

        // Accumulate platform fees
        accumulatedFees += platformFee;

        // INTERACTIONS: return collateral last
        if (loan.collateralAmount > 0) {
            usdcToken.safeTransfer(loan.borrower, loan.collateralAmount);
        }

        // Record with reputation manager
        bool onTime = block.timestamp <= loan.endTime;
        reputationManager.recordLoanCompletion(loan.borrower, loan.amount, onTime);

        emit LoanRepaid(loanId, loan.amount, interest);
    }

    /**
     * @notice Distribute interest to lenders proportionally
     */
    function _distributeInterest(uint256 agentId, uint256 totalInterest) internal {
        AgentPool storage pool = agentPools[agentId];
        address[] storage lenders = poolLenders[agentId];

        // [H-01 FIX] Track distributed amount to credit rounding dust to platform fees
        uint256 distributed = 0;

        for (uint256 i = 0; i < lenders.length; i++) {
            address lender = lenders[i];
            LenderPosition storage position = positions[agentId][lender];

            if (position.amount > 0) {
                // Calculate lender's share based on their proportion of the pool
                uint256 share = (totalInterest * position.amount) / pool.totalLiquidity;
                position.earnedInterest += share;
                distributed += share;
            }
        }

        // Credit any remainder (rounding dust) as platform fees rather than trapping it
        uint256 dust = totalInterest - distributed;
        if (dust > 0) {
            accumulatedFees += dust;
        }

        emit InterestDistributed(agentId, totalInterest);
    }

    /**
     * @notice Liquidate a defaulted loan
     */
    function liquidateLoan(uint256 loanId) external onlyOwner nonReentrant {
        Loan storage loan = loans[loanId];
        require(loan.state == LoanState.ACTIVE, "Loan not active");
        require(block.timestamp > loan.endTime, "Loan not overdue");

        AgentPool storage pool = agentPools[loan.agentId];

        // [H-02 FIX] Correctly account for principal loss when collateral < loan amount
        uint256 recovered = loan.collateralAmount;
        uint256 loss = loan.amount > recovered ? loan.amount - recovered : 0;

        // Seize collateral (what we actually recover)
        pool.availableLiquidity += recovered;

        // Reduce totalLiquidity by the unrecovered loss so it reflects real pool value
        if (loss > 0) {
            pool.totalLiquidity -= loss;
        }

        // Update loaned amount
        pool.totalLoaned -= loan.amount;

        // Mark as defaulted
        loan.state = LoanState.DEFAULTED;

        // §S5 FIX: decrement counter on transition out of ACTIVE
        activeLoanCount[loan.borrower]--;

        // Record default with reputation manager
        reputationManager.recordDefault(loan.borrower, loan.amount);

        emit LoanDefaulted(loanId);
    }

    /**
     * @notice Calculate interest for a loan
     */
    function calculateInterest(
        uint256 principal,
        uint256 annualRateBPS,
        uint256 durationSeconds
    ) public pure returns (uint256) {
        uint256 annualInterest = (principal * annualRateBPS) / 10000;
        uint256 interest = (annualInterest * durationSeconds) / 365 days;
        return interest;
    }

    /**
     * @notice Get agent pool details
     */
    function getAgentPool(uint256 agentId) external view returns (
        address agentAddress,
        uint256 totalLiquidity,
        uint256 availableLiquidity,
        uint256 totalLoaned,
        uint256 totalEarned,
        uint256 utilizationRate,
        uint256 lenderCount
    ) {
        AgentPool memory pool = agentPools[agentId];
        uint256 utilization = pool.totalLiquidity > 0
            ? (pool.totalLoaned * 10000) / pool.totalLiquidity
            : 0;

        return (
            pool.agentAddress,
            pool.totalLiquidity,
            pool.availableLiquidity,
            pool.totalLoaned,
            pool.totalEarned,
            utilization,
            poolLenders[agentId].length
        );
    }

    /**
     * @notice Get lender position for an agent
     */
    function getLenderPosition(uint256 agentId, address lender) external view returns (
        uint256 amount,
        uint256 earnedInterest,
        uint256 depositTimestamp,
        uint256 shareOfPool
    ) {
        LenderPosition memory position = positions[agentId][lender];
        AgentPool memory pool = agentPools[agentId];

        uint256 share = pool.totalLiquidity > 0
            ? (position.amount * 10000) / pool.totalLiquidity
            : 0;

        return (
            position.amount,
            position.earnedInterest,
            position.depositTimestamp,
            share
        );
    }

    /**
     * @notice Get all active agent pools (for browsing)
     */
    function getActiveAgents() external view returns (uint256[] memory) {
        // Note: This requires tracking active agent IDs separately for gas efficiency
        // For now, front-end should query by known agent IDs
        // TODO: Add agentId array tracking if needed
        revert("Use front-end to query specific agents");
    }

    /**
     * @notice Claim earned interest
     */
    function claimInterest(uint256 agentId) external nonReentrant whenNotPaused {
        LenderPosition storage position = positions[agentId][msg.sender];
        AgentPool storage pool = agentPools[agentId];
        uint256 interest = position.earnedInterest;

        require(interest > 0, "No interest to claim");

        position.earnedInterest = 0;

        // §S1 FIX: decrement pool.availableLiquidity to match the USDC leaving the contract.
        // Without this, claimed interest is double-counted as both "withdrawn USDC" and "still
        // available", producing the phantom liquidity drift documented in the audit.
        require(pool.availableLiquidity >= interest, "Drain underflow");
        pool.availableLiquidity -= interest;

        usdcToken.safeTransfer(msg.sender, interest);
        emit InterestClaimed(agentId, msg.sender, interest);
    }

    /**
     * @notice Owner withdraws platform fees
     */
    function withdrawFees(uint256 amount) external onlyOwner nonReentrant {
        require(amount <= accumulatedFees, "Insufficient fees");
        accumulatedFees -= amount;
        usdcToken.safeTransfer(owner(), amount);
        emit FeesWithdrawn(owner(), amount);
    }

    /**
     * @notice Emergency pause
     */
    function pause() external onlyOwner {
        _pause();
    }

    /**
     * @notice Unpause
     */
    function unpause() external onlyOwner {
        _unpause();
    }

    // ===================================================================================
    // Migration helpers (owner-only, locked once `setMigrationFinalized()` is called).
    // Used to seed state from a v4 snapshot. After finalization, normal operation only.
    // ===================================================================================

    modifier whileMigrating() {
        require(!migrationFinalized, "Migration finalized");
        _;
    }

    /**
     * @notice Seed an agent pool from a v4 snapshot.
     * @dev Owner only, while migrating. Marks pool active. Adds to agentPoolIds if new.
     */
    function seedPool(
        uint256 agentId,
        address agentAddress,
        uint256 totalLiquidity,
        uint256 availableLiquidity,
        uint256 totalEarned
    ) external onlyOwner whileMigrating {
        require(agentId != 0, "Invalid agentId");
        require(agentAddress != address(0), "Invalid agentAddress");
        AgentPool storage pool = agentPools[agentId];
        bool isNew = (pool.agentId == 0);

        pool.agentId = agentId;
        pool.agentAddress = agentAddress;
        pool.totalLiquidity = totalLiquidity;
        pool.availableLiquidity = availableLiquidity;
        pool.totalLoaned = 0; // active loans not migrated; assume freshly loaned out is 0
        pool.totalEarned = totalEarned;
        pool.isActive = true;

        if (isNew) {
            agentPoolIds.push(agentId);
            emit PoolCreated(agentId, agentAddress);
        }
        emit PoolSeeded(agentId, agentAddress);
    }

    /**
     * @notice Seed a lender's position. Pushes to poolLenders[] if not already present.
     * @dev §B1-fix-aware: uses isInPoolLenders flag. No duplicates created.
     */
    function seedPosition(
        uint256 agentId,
        address lender,
        uint256 amount,
        uint256 earnedInterest,
        uint256 depositTimestamp
    ) external onlyOwner whileMigrating {
        require(lender != address(0), "Invalid lender");
        require(agentPools[agentId].agentId == agentId, "Pool not seeded");

        positions[agentId][lender] = LenderPosition({
            amount: amount,
            earnedInterest: earnedInterest,
            depositTimestamp: depositTimestamp
        });

        if (!isInPoolLenders[agentId][lender]) {
            require(poolLenders[agentId].length < MAX_LENDERS_PER_POOL, "Lender cap");
            poolLenders[agentId].push(lender);
            isInPoolLenders[agentId][lender] = true;
        }
        emit PositionSeeded(agentId, lender, amount, earnedInterest);
    }

    /**
     * @notice Dedup poolLenders[] in-place. Useful for sanitizing state if a malformed
     *         seed was pushed before finalization.
     */
    function compactPoolLenders(uint256 agentId) external onlyOwner {
        address[] storage list = poolLenders[agentId];
        // Reset flags
        for (uint256 i = 0; i < list.length; i++) {
            isInPoolLenders[agentId][list[i]] = false;
        }
        // Rebuild deduped list in-place
        uint256 writeIdx = 0;
        for (uint256 i = 0; i < list.length; i++) {
            address lender = list[i];
            if (!isInPoolLenders[agentId][lender]) {
                isInPoolLenders[agentId][lender] = true;
                list[writeIdx] = lender;
                writeIdx++;
            }
        }
        uint256 removed = list.length - writeIdx;
        while (list.length > writeIdx) list.pop();
        emit PoolLendersCompacted(agentId, removed);
    }

    /**
     * @notice Finalize migration. After this is called, seed* functions revert.
     * @dev Irreversible. Call only after all v4 state has been transferred.
     */
    function setMigrationFinalized() external onlyOwner whileMigrating {
        migrationFinalized = true;
        emit MigrationFinalized();
    }

    /**
     * @notice Update platform fee rate
     */
    function setPlatformFeeRate(uint256 newRate) external onlyOwner {
        require(newRate <= 500, "Fee too high"); // Max 5%
        platformFeeRate = newRate;
    }

    /**
     * @notice Emergency function to recalculate and fix pool accounting
     * @dev Recalculates totalLoaned by summing active loans for agent
     * @param agentId The agent ID whose pool to fix
     */
    function resetPoolAccounting(uint256 agentId) external onlyOwner {
        AgentPool storage pool = agentPools[agentId];
        require(pool.agentId == agentId, "Pool does not exist");

        // Recalculate totalLoaned from active loans
        uint256 actualLoaned = 0;
        uint256[] memory loanIds = agentLoans[pool.agentAddress];

        for (uint256 i = 0; i < loanIds.length; i++) {
            Loan storage loan = loans[loanIds[i]];
            if (loan.state == LoanState.ACTIVE) {
                actualLoaned += loan.amount;
            }
        }

        // Update pool state
        uint256 oldLoaned = pool.totalLoaned;
        pool.totalLoaned = actualLoaned;
        pool.availableLiquidity = pool.totalLiquidity + pool.totalEarned - actualLoaned;

        emit PoolAccountingReset(agentId, oldLoaned, actualLoaned, pool.availableLiquidity);
    }

    /**
     * @notice Count active loans for an agent
     * @dev §S5 FIX: O(1) lookup via activeLoanCount counter, replaces array walk.
     *      The counter is maintained at requestLoan (++), repayLoan (--), liquidateLoan (--).
     */
    function _countActiveLoans(address agent) internal view returns (uint256) {
        return activeLoanCount[agent];
    }

    /**
     * @notice Legacy O(N) implementation, retained for verifying counter integrity in tests.
     */
    function _countActiveLoansFromArray(address agent) internal view returns (uint256) {
        uint256[] memory loanIds = agentLoans[agent];
        uint256 activeCount = 0;

        for (uint256 i = 0; i < loanIds.length; i++) {
            if (loans[loanIds[i]].state == LoanState.ACTIVE) {
                activeCount++;
            }
        }

        return activeCount;
    }

    // Events
    event PoolAccountingReset(
        uint256 indexed agentId,
        uint256 oldTotalLoaned,
        uint256 newTotalLoaned,
        uint256 newAvailableLiquidity
    );
}
